import React from 'react'

function TagNavbar() {
  return (
    <div>TagNavbar</div>
  )
}

export default TagNavbar