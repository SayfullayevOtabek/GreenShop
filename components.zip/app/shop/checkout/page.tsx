import React from 'react'

const CheckOutPage = () => {
  return (
    <div>CheckOut Page</div>
  )
}

export default CheckOutPage