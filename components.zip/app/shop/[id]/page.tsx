"use client"
import { CustomImage } from '@/components/CustomImage'
import HeroProduct from '@/components/HeroCarusel/HeroProduct'
import { URL } from '@/service/resquest'
import axios from 'axios'
import Image from 'next/image'
import React, { useEffect, useState } from 'react'



const SinglePage = ({params}:any) => {
 const id = params.id
 const [singleData, setSingleData] = useState<any>([])
 const [mainImage, setMainImage] = useState<string>("")
 useEffect(() => {
  axios.get(`${URL}/product/${id}`).then(res => {
    setSingleData(res.data);
    setMainImage(res.data.image_url[0])
    console.log(res.data)
  })
 },[])
 


  return (
      <div className="container">
      <div>
      {/* <p className="font-bold text-[15px]">Home / <span className="font-normal">Shop/{id}</span></p> */}
        {singleData?.product_name}
        <div className='h-[444px] w-[573px] overflow-hidden flex justify-between'>
          <div className='w-[20%] h-[444px] overflow-y-auto cursor-pointer'>
            {singleData?.image_url?.map((item:any, index:number) => (
                <Image className='border-[1px] border-slate-400' onClick={() => setMainImage(item)} key={index} alt='Product Img' height={100} width={100} src={item} property='true'/> 
            ))}
          </div>
          <div className='w-[80%]'>
              <Image className='border-[1px] border-slate-400' alt='Product Img' height={444} width={444} src={mainImage} property="true"/> 
          </div>
        </div>
      <p className="font-bold text-[17px] mt-[100px] leading-[16px] text-[#46A358]">Releted Products</p>
      <div className="w-[1200px] bg-[#46A358] opacity-30 h-[1px] mt-[12px]"></div>
        <HeroProduct/>
      
    </div>
      </div>
  )
}

export default SinglePage