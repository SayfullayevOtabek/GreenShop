import React from "react";

const Blogs = () => {
  return <div>Blogs page</div>;
};

export default Blogs;
