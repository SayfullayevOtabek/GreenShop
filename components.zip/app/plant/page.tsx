import React from "react";

const Plant = () => {
  return <div>Plant Care page</div>;
};

export default Plant;
